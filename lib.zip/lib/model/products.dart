import 'package:flutter/material.dart';

class Product<String>{
  final String title;
  final String image;
  final String desc;
  final int price;
  final int size;
  final int id;
  final Color color;

  Product({
    required this.title,
    required this.image,
    required this.desc,
    required this.price,
    required this.size,
    required this.id,
    required this.color,
});
}

List<Product> products = [
  Product(
      id: 1,
      title: "Office Code",
      price: 234,
      size: 12,
      desc: dummyText,
      image: "images/blue.png",
      color: Color(0xFF3D82AE)),
  Product(
      id: 2,
      title: "Belt Shade",
      price: 234,
      size: 8,
      desc: dummyText,
      image: "images/yellow.png",
      color: Color(0xFFEED619)),
  Product(
      id: 3,
      title: "Han Top",
      price: 234,
      size: 10,
      desc: dummyText,
      image: "images/black.png",
      color: Color(0xFF000000)),
  Product(
      id: 4,
      title: "Old Fashion",
      price: 234,
      size: 11,
      desc: dummyText,
      image: "images/orange.png",
      color: Color(0xFFEA5631)),
  Product(
      id: 5,
      title: "Office Code",
      price: 234,
      size: 12,
      desc: dummyText,
      image: "images/9.png",
      color: Color(0xFF9A4B16)),
  Product(
    id: 6,
    title: "Office Code",
    price: 234,
    size: 12,
    desc: dummyText,
    image: "images/pink.png",
    color: Color(0xFFD70DB8),
  ),
];

String dummyText =
    "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since. When an unknown printer took a galley.";
