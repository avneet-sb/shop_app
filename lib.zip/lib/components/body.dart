import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shop_app/model/products.dart';
import 'package:shop_app/screens/product_details.dart';


class Body extends StatelessWidget {
  const Body({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Women",
            style: GoogleFonts.lato(
                fontSize: 25,
                fontWeight: FontWeight.bold
            ),
          ),
          Categories(),
          Expanded(
              child:
              GridView.builder(itemCount: products.length,
                  physics: BouncingScrollPhysics(),
                  gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, 
                      childAspectRatio: 0.75
          ), itemBuilder: (context, index)=>
                  ItemCard(product: products[index], press: ()=>
                  Navigator.of(context).push(
                    MaterialPageRoute(builder:
                    (context)=> ProductDetails(product: products[index],)
                    )
                  )
                  )
              ))
        ],
      ),
    );
  }
}

class ItemCard extends StatelessWidget {
  final Product product;
  final Function press;
  const ItemCard({
    Key? key, required this.product, required this.press,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: EdgeInsets.all(10),
          height: 180,
          width: 160,
          decoration: BoxDecoration(
            color: product.color,
            borderRadius: BorderRadius.circular(20)
          ),
          child: Image.asset(product.image),
        ),
        Expanded(
          child: TextButton(onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(
                builder: (context)=>
                    ProductDetails(product: product)
            ));
          },
            child: Text("${product.title}"),
            style: TextButton.styleFrom(
              primary: Colors.black
            )
          ),
        ),
        Expanded(
          child: Row(
            children: [SizedBox(width: 10,),
              Text("\$${product.price}",
                style: GoogleFonts.lato(
                    color: Colors.grey,
                    fontSize: 15
                ),
              ),
            ],
          ),
        )

      ],
    );
  }
}


class Categories extends StatefulWidget {
  const Categories({Key? key}) : super(key: key);

  @override
  _CategoriesState createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  List<String> categories = ["HandBag", "Jewellery", "Footwear", "Dresses"];
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10),
      child: SizedBox(
        height: 35,
        child: ListView.builder(
          physics: BouncingScrollPhysics(),
        scrollDirection: Axis.horizontal,       // for the scroll direction of the list.
        itemCount: categories.length,
        itemBuilder:(context, index){
          return GestureDetector(
            onTap: (){
              setState(() {
                selectedIndex = index;
              });
            },
            child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(categories[index],
                    style: GoogleFonts.lato(
                      fontSize: 15,
                      color: selectedIndex == index ? Colors.black: Colors.grey,
                      fontWeight: FontWeight.bold
                    ),
                    ),
                    Container(
                      height: 3,
                      width: 30,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(2),
                        color: selectedIndex == index ? Colors.grey : Colors.transparent
                      ),
                    )
                  ],
                ),
            ),
          );
        }
        ),
      ),
    );
  }
}





