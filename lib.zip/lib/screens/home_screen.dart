import 'package:flutter/material.dart';
import 'package:shop_app/components/body.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0.0,
        leading: IconButton(
          onPressed:(){
            Navigator.of(context).pop();
          } ,
          icon: Icon(Icons.arrow_back_rounded),
          color: Color(0xFF7F7D7D),
        ),
        actions: [
          IconButton(
              onPressed: (){},
              icon: Icon(Icons.search),
            color: Color(0xFF7F7D7D),
          ),
          Padding(
            padding: EdgeInsets.all(5),
            child: IconButton(
                onPressed: (){},
                icon: Icon(Icons.add_shopping_cart),
              color: Color(0xFF7F7D7D),
            ),
          )
        ],
      ),
      body: Body(),
    );
  }
}
