import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shop_app/model/products.dart';

class ProductDetails extends StatelessWidget {
  final Product product;
  const ProductDetails({Key? key, required this.product}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: product.color,
      appBar: AppBar(
        backgroundColor: product.color,
        elevation: 0,
        actions: [
          IconButton(onPressed: (){}, icon: Icon(Icons.search)),
          IconButton(onPressed: (){}, icon: Icon(Icons.add_shopping_cart)),
          SizedBox(width: 10,)
        ],
      ),
      body: DetailsBody(product: product) ,
    );
  }
}

class DetailsBody extends StatelessWidget {
  final Product product;
  const DetailsBody({Key? key, required this.product}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        children: <Widget>[
          SizedBox(
            height: size.height,
            child: Stack(
              children: <Widget>[
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        height: 500,
                       // margin: EdgeInsets.only(top: size.height * 3),
                        padding: EdgeInsets.only(top: size.height * 0.12,
                        left: size.height * 0.03,
                        right: size.height * 0.06),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(34),
                            topRight: Radius.circular(34)
                          )
                        ),
                        child: Column(
                          children: [
                            Row(

                              children: [
                                Text("Color: ",
                                  style: GoogleFonts.lato(
                                    fontSize: 17
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(right: 20),
                                  padding: EdgeInsets.all(2),
                                  height: 20,
                                  width: 20,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: product.color
                                    ),
                                  ),
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      color: product.color,
                                      shape: BoxShape.circle
                                    ),
                                  ),
                                ),
                               Spacer(),
                               Padding(
                                 padding: EdgeInsets.only(right: 30,top: 10),
                                 child: Column(
                                   children: [
                                     Text(
                                       "Size:",
                                       style: GoogleFonts.lato(
                                         fontSize: 17
                                       ),
                                     ),
                                     Text("${product.size} cm",
                                     style: GoogleFonts.lato(
                                       fontSize: 30,
                                       fontWeight: FontWeight.bold
                                     ),
                                     )
                                   ],
                                 ),
                               )
                              ],
                            ),
                            SizedBox(height: 10,),
                            Text(product.desc,
                            style: GoogleFonts.lato(
                              fontSize: 13,

                            ),),
                            SizedBox(height: 10,),
                            Button(),
                            SizedBox(height: 10,),
                            Row(
                              children: [
                                OutlinedButton(onPressed: (){},
                                    child: Icon(Icons.add_shopping_cart),
                               ),
                                SizedBox(width: 10,),
                                Expanded(
                                  child: TextButton(onPressed: (){},
                                      child:Text("Buy Now"),
                                  style: TextButton.styleFrom(elevation: 10,
                                    backgroundColor: Colors.white,
                                    textStyle: TextStyle(
                                      fontSize: 30,
                                      color: Colors.black,
                                    )
                                  ),),
                                )
                              ],

                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Aristocratic handbag",
                      style: GoogleFonts.lato(
                        color: Colors.white,
                        fontSize: 14
                      ),
                      ),
                      Text(product.title,
                        style: GoogleFonts.lato(
                            color: Colors.white,
                            fontSize: 35,
                          fontWeight: FontWeight.bold
                      )
                      ),
                      SizedBox(height: 10,),
                      Row(
                        children: [
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(text: "Price\n"),
                                TextSpan(text: "\$${product.price}",
                                style: GoogleFonts.lato(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 30
                                ))
                              ]
                            ),
                          ),
                          Expanded(child: Image.asset(product.image,
                          fit: BoxFit.fill,
                          ))
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

class Button extends StatefulWidget {
  const Button({Key? key}) : super(key: key);

  @override
  _ButtonState createState() => _ButtonState();
}

class _ButtonState extends State<Button> {
  int totalItems = 1;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.zero,
      child: Row(
        children: [
          OutlinedButton(onPressed:(){
            if(totalItems>1){
              setState(() {
                totalItems--;
              });
            }
          },
              child: Icon(Icons.remove)
          ),
          SizedBox(width: 10,),
          Text(totalItems.toString()),
          SizedBox(width: 10,),
          OutlinedButton(onPressed:(){
            setState(() {
              totalItems++;
            });
          },
              child: Icon(Icons.add),

          ),

        ],
      ),
    );
  }
}


