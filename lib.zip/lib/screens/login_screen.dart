import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shop_app/screens/home_screen.dart';



class LoginPage extends StatefulWidget {
  const LoginPage({Key? key, }) : super(key: key);


  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0xFFD1EEE4),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          color: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 15,),
                Container(
                  height: 45,
                  width: 300,

                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.lightBlueAccent,
                        Colors.greenAccent,
                        Colors.lightBlueAccent
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight
                      ),
                      borderRadius: BorderRadius.circular(20)
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(5),
                      child: Center(
                        child: Text(
                            "ShoppersStop",
                          style: GoogleFonts.josefinSans(
                            fontSize: 40,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueAccent
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 15,),
                Center(
                  child: CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.white,
                    child: CircleAvatar(
                      radius: 47,
                      backgroundColor: Colors.lightBlue,
                      child:Image.asset("images/logo.png"),
                    ),
                  ),
                ),
                Spacer(),
                Text(
                  "Welcome back!",
                  style: GoogleFonts.lato(
                    fontSize: 40,
                    color: Colors.black87,
                    fontWeight: FontWeight.bold
                  ),
                ),
                Text(
                  "Click to continue.",
                  style: GoogleFonts.lato(
                      fontSize: 18,
                      color: Colors.black87
                  ),
                ),
                Spacer(),
                Center(
                  child: ElevatedButton(onPressed: (){
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (context)=>HomeScreen())
                    );
                  },style: ElevatedButton.styleFrom(
                    elevation: 20,
                    padding: EdgeInsets.all(10),
                    primary: Colors.lightBlue,
                    textStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 30
                    )
                  ),
                      child: Text(
                        "Go to main screen ->"
                      ),
                  ),
                ),
                Spacer(),

              ],
            ),
          ),
        ),
      ),
    );
  }
}
